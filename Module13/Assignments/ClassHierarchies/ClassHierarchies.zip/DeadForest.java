package Module13.Assignments;

public class DeadForest extends Forest {
    public DeadForest(int l, int w) {
        super(l, w, "Dead Forest");
    }
}
