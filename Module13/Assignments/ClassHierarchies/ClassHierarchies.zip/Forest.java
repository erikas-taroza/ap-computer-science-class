package Module13.Assignments;

public class Forest extends Terrain {
    public Forest(int l, int w, String landName) {
        super(l, w, landName);
    }
}
