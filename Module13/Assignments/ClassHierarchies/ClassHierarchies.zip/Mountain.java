package Module13.Assignments;

public class Mountain extends Terrain {

    public Mountain(int l, int w, String landName) {
        super(l, w, landName);
    }
}
