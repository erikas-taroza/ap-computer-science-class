package Module13.Assignments;

public class WinterMountain extends Mountain {
    public WinterMountain(int l, int w) {
        super(l, w, "Winter Mountain");
    }
}
