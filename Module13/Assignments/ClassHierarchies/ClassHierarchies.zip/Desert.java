package Module13.Assignments;

public class Desert extends Terrain {
    public Desert(int l, int w) {
        super(l, w, "Desert");
    }
}
