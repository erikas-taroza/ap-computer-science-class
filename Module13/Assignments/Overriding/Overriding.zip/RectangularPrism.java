package Module13.Assignments.Overriding;

public class RectangularPrism extends Box4 {

    public RectangularPrism(int l, int w, int h) {
        super(l, w, h);
    }

    @Override
    public String toString() {
        return "The rectangular prism's dimensions are " + getLength() + " X " + getWidth() + " X " + getHeight();
    }
}
