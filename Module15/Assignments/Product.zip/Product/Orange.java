package Module15.Assignments.Product;

public class Orange extends Food {
    public Orange(String name, double cost) {
        super(name, cost);
    }

    @Override
    public void Consume() {

    }
}
