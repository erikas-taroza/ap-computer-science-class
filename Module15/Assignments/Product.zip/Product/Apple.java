package Module15.Assignments.Product;

public class Apple extends Food {
    public Apple(String name, double cost) {
        super(name, cost);
    }

    @Override
    public void Consume() {

    }
}
