package Module15.Assignments.Product;

public class HandDrill extends Tool {

    public HandDrill(String name, double cost) {
        super(name, cost);
    }
}
