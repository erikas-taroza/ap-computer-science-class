package Module15.Assignments.Product;

public interface IProduct {
    public abstract String GetName();

    public abstract double GetCost();
}
