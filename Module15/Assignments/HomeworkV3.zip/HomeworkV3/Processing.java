package Module15.Assignments.HomeworkV3;

public interface Processing {
    public abstract void DoHomework(int pagesDone);
}
