package Module15.Assignments.HomeworkV4;

public interface Processing {
    public abstract void DoHomework(int pagesDone);
}
