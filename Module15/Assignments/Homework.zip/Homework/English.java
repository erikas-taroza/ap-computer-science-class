package Module15.Assignments.Homework;

public class English extends Homework {

    public English() {
        super();
    }

    public void CreateHomework(int pages, String type) {
        super.SetPages(pages);
        super.SetType(type);
    }
}
