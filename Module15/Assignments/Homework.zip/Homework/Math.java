package Module15.Assignments.Homework;

public class Math extends Homework {

    public Math() {
        super();
    }

    public void CreateHomework(int pages, String type) {
        super.SetPages(pages);
        super.SetType(type);
    }
}
