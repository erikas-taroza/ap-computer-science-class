package Module15.Assignments.Homework;

public class Science extends Homework {

    public Science() {
        super();
    }

    public void CreateHomework(int pages, String type) {
        super.SetPages(pages);
        super.SetType(type);
    }
}
