package Module15.Assignments.Homework;

public class Spanish extends Homework {

    public Spanish() {
        super();
    }

    public void CreateHomework(int pages, String type) {
        super.SetPages(pages);
        super.SetType(type);
    }
}
